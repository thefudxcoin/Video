const connect = document.querySelector(".connect");
const mint = document.querySelector(".mint");
const register = document.querySelector(".register");
const claimBtn = document.querySelector(".claimBtn");


const EvmChains = window.evmChains;
const Web3Modal = window.Web3Modal.default;
const WalletConnectProvider = window.WalletConnectProvider.default;
let web3Modal;
let provider;
let balance;
let userAddress;


// const abi = [{"inputs":[],"name":"buyTokens","outputs":[],"stateMutability":"payable","type":"function"},{"inputs":[{"internalType":"uint40","name":"_code","type":"uint40"}],"name":"claimAirdrop","outputs":[{"internalType":"bool","name":"success","type":"bool"}],"stateMutability":"nonpayable","type":"function"}]
const abi = [{"inputs":[],"name":"buyTokens","outputs":[],"stateMutability":"payable","type":"function"},{"inputs":[{"internalType":"uint40","name":"_code","type":"uint40"}],"name":"claimAirdrop","outputs":[{"internalType":"bool","name":"success","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"register","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"}],"name":"registered","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"}]

// const contractAddress = '0x13B56B922d0cd5fC0A2ffa7554008bF2a9D528e1';
const contractAddress = '0x0Ef1b1afe2f6Bb78D4A032202B74874f65EcD231';


function init() {
  const providerOptions = {
    walletconnect: {
      package: WalletConnectProvider,
      options: {
        rpc: {
          // 1: "https://main-light.eth.linkpool.io/",
          4: "https://rinkeby-light.eth.linkpool.io/",
        },
      },
    },
  };

  web3Modal = new Web3Modal({
    network: "mainnet",
    cacheProvider: false,
    providerOptions,
  });
}

async function onConnect() {
  try {
    provider = await web3Modal.connect();
  } catch (e) {
    console.log("Could not get a wallet connection", e);
    return;
  }
  provider.on("accountsChanged", (accounts) => {
    fetchAccountData();
  });
  provider.on("chainChanged", (chainId) => {
    fetchAccountData();
  });

  provider.on("networkChanged", (networkId) => {
    fetchAccountData();
  });
  await fetchAccountData();
}

async function fetchAccountData() {
  const web3 = new Web3(provider);
  const chainId = await web3.eth.getChainId();
  console.log(chainId);
  const chainData = await EvmChains.getChain(chainId);
  console.log(chainData.name);
  // if (chainId !== 1) return alert("Connect wallet to a Ethereum Chain Mainnet");
  if (chainId !== 4) return alert("Connect wallet to a Ethereum Chain Mainnet");
  const accounts = await web3.eth.getAccounts();
  selectedAccount = accounts[0];
  userAddress = selectedAccount;
  showAddress(selectedAccount);
  Balance(selectedAccount);
  console.log("selected-account", selectedAccount);
}

const Balance = async (address) => {
  const web3 = new Web3(provider);
  const bal = await web3.eth.getBalance(address);
  balance = (bal / (10**18)).toFixed(3);
  let Address = showAddress(address);
  connect.classList.add('connect_btn')
  connect.innerHTML = `<span>${balance} ETH</span> <p>${Address} <i class="far fa-clone"></i></p>`;
};


function showAddress(num) {
  const firstAddressPart = shortener(num, 0, 6);
  const lastAddressPart = shortener(num, 36, 42);
  return `${firstAddressPart}...${lastAddressPart}`;
}

const shortener = (_data, _start, _end) => {
  let result = "";
  for (let i = _start; i < _end; i++) result = [...result, _data[i]];

  return result.join("");
};

const Mint = async() => {
    const web3 = new Web3(provider);
    let Contract = web3.eth.Contract;
    let contract = new Contract(abi, contractAddress);
    let amount = document.querySelector('.amount').value;
    amount = parseInt(amount)
    
    if(amount){
            contract.methods.buyTokens().send({
                from : userAddress,
                value: amount * (10**18)
            })
          }
else{
        window.alert('Plz Enter Your Token Amount !')
    }
}

const Register = async() =>{
  const web3 = new Web3(provider);
  let Contract = web3.eth.Contract;
  let contract = new Contract(abi, contractAddress);
  try {
    contract.methods.register().send({
      from: userAddress,
      // gas: 50000, 
      // gasPrice: '42000000000'
    })
  } catch (error) {
    console.log(error)
  }
}

const Claim = async() => {
   const web3 = new Web3(provider);
    let Contract = web3.eth.Contract;
    let contract = new Contract(abi, contractAddress);
    let code = document.querySelector('.code').value;
    code = parseInt(code)
    if(code){
            contract.methods.claimAirdrop(code).send({
                from : userAddress,
                // gas: 50000, 
                // gasPrice: '42000000000'
            })
        }else{
        window.alert('Plz Enter Your Correct Code !')
    }
}



window.addEventListener("load", () => {
  init();
});

connect.addEventListener("click", function () {
  if (!balance) {
    onConnect();
  }
});



mint.addEventListener('click' , ()=>{
    if(balance){
        Mint()
    }else{
        onConnect()
    }
})

claimBtn.addEventListener('click' , ()=>{
    if(balance){
        Claim()
    }else{
        onConnect()
    }
})

register.addEventListener('click' , ()=>{
    if(balance){
        Register()
    }else{
        onConnect()
    }
})



